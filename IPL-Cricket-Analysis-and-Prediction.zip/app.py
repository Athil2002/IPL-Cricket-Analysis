def main():
    print('Run project from src modules or notebook')

if __name__ == '__main__':
    main()
