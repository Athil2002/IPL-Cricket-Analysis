# IPL Cricket Analysis and Prediction

Project skeleton.
