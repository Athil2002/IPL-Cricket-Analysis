def clean_matches(df):
    df = df.copy()
    df.columns = [c.strip() for c in df.columns]
    return df
