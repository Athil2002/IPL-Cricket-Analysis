def predict(row):
    return {'pred': None}
