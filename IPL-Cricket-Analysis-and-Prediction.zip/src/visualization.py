def sample_plot():
    return None
