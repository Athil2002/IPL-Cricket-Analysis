def create_features(df):
    return df
