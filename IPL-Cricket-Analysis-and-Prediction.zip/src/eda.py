def plot_matches_per_season(df):
    return 'placeholder'
