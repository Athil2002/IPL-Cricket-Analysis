import os
import pandas as pd

def load_matches(data_dir='data'):
    return pd.read_csv(os.path.join(data_dir, 'IPL_Matches_2008_2022.csv'))
